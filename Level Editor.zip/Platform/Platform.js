import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Platform extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "Simple Platform",
        "./Platform/costumes/Simple Platform.svg",
        { x: 71.50000000000003, y: 16 }
      )
    ];

    this.sounds = [new Sound("pop", "./Platform/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Screen Update" },
        this.whenIReceiveScreenUpdate
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];

    this.vars.blockY2 = 175.47611986461177;
    this.vars.blockX2 = -192;
  }

  *whenthisspriteclicked() {}

  *whenIReceiveScreenUpdate() {}

  *whenGreenFlagClicked() {
    this.vars.blockX2 = 0;
    this.vars.blockY2 = -68;
    this.createClone();
    while (true) {
      this.vars.blockX2 = this.mouse.x - this.stage.vars.camX;
      this.vars.blockY2 = this.mouse.y - this.stage.vars.camY;
      this.goto(
        this.vars.blockX2 + this.stage.vars.camX,
        this.vars.blockY2 + this.stage.vars.camY
      );
      yield;
    }
  }

  *startAsClone() {
    while (true) {
      this.goto(
        this.vars.blockX2 + this.stage.vars.camX,
        this.vars.blockY2 + this.stage.vars.camY
      );
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.keyPressed("a")) {
        this.createClone();
        while (!!this.keyPressed("a")) {
          yield;
        }
      }
      yield;
    }
  }
}
