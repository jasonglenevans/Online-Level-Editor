import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Controls extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Controls/costumes/costume1.svg", {
        x: 130.9599609375,
        y: 50.59375
      })
    ];

    this.sounds = [new Sound("pop", "./Controls/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.goto(this.stage.vars.camX, this.stage.vars.camY + 150);
      yield;
    }
  }
}
