import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Player extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("LPlayer", "./Player/costumes/LPlayer.png", {
        x: 91,
        y: 236
      }),
      new Costume("RPlayer", "./Player/costumes/RPlayer.png", {
        x: 117,
        y: 236
      })
    ];

    this.sounds = [new Sound("Meow", "./Player/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];

    this.vars.blockY = 0;
    this.vars.blockX = 0;
  }

  *platform() {
    this.stage.vars.playerYVel += -1;
    this.y += this.stage.vars.playerYVel;
    this.stage.vars.playerY += this.stage.vars.playerYVel;
    if (this.touching(this.sprites["Platform"].andClones())) {
      while (!!this.touching(this.sprites["Platform"].andClones())) {
        if (this.stage.vars.playerYVel < 1) {
          this.y += 1;
          this.stage.vars.playerY += 1;
        } else {
          this.y += -1;
          this.stage.vars.playerY += -1;
        }
      }
      this.stage.vars.playerYVel = 0;
      this.y += -6;
      if (this.keyPressed("space")) {
        this.stage.vars.playerYVel = 15;
      }
    }
    if (this.keyPressed("right arrow")) {
      this.costume = "RPlayer";
      this.stage.vars.playerXVel += 1;
    }
    if (this.keyPressed("left arrow")) {
      this.costume = "LPlayer";
      this.stage.vars.playerXVel += -1;
    }
    this.stage.vars.playerXVel = this.stage.vars.playerXVel * 0.9;
    this.stage.vars.playerX += this.stage.vars.playerXVel;
    this.x += this.stage.vars.playerXVel;
    if (this.stage.vars.playerY < -1000) {
      this.stage.vars.playerX = 0;
      this.stage.vars.playerY = 0;
      this.stage.vars.playerYVel = 0;
      this.stage.vars.playerXVel = 0;
    }
    this.goto(
      this.stage.vars.playerX + this.stage.vars.camX,
      this.stage.vars.playerY + this.stage.vars.camY
    );
    this.stage.vars.camX +=
      (this.stage.vars.playerX * -1 - this.stage.vars.camX) / 7;
    this.stage.vars.camY +=
      (this.stage.vars.playerY * -1 - this.stage.vars.camY) / 7;
  }

  *whenGreenFlagClicked() {
    this.stage.vars.camX = 0;
    this.stage.vars.camY = 0;
    this.stage.vars.playerX = 0;
    this.stage.vars.playerY = 0;
    this.stage.vars.playerXVel = 0;
    this.costume = "RPlayer";
    while (true) {
      yield* this.platform();
      yield;
    }
  }
}
